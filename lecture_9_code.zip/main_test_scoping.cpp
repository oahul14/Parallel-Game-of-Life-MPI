#include <iostream>
#include <math.h>
#include <ctime>

using namespace std;

// Function is just going to assign the value of an int
// Reference version here
int& assignInt()
// Non-refrence version here, this is the one that will work
//int assignInt()
{
   // This is stored on the stack
   int i = 0;
   return i;
}

int main()
{

   // Will this work??
   int i = assignInt();
   cout << "value of i: " << i << endl;

   system("pause");

}