#pragma once
#include <string>
#include "Animal.h"

class Horse : public Animal
{
public:
	int GetNumberOfLegs();
	std::string GetClass();
};