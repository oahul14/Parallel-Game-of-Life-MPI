#include <iostream>
#include <string>

using namespace std;

int main()
{
	cerr << "\nDBL_MAX + DBL_MAX: " << DBL_MAX + DBL_MAX << "\n";
	cerr << "\nDBL_MAX + 1000: " << DBL_MAX + 1000 << "\n";
	cerr << "\nDBL_MAX / (DBL_MAX + DBL_MAX): " << DBL_MAX / (DBL_MAX + DBL_MAX) << "\n ";
	cerr << "\nINT_MAX + INT_MAX: " << INT_MAX + INT_MAX << "(INT Behaves differently!)\n\n\n ";
	
	{double max = std::numeric_limits<double>::max();
	double inf = std::numeric_limits<double>::infinity();

	if (inf > max)
		std::cout << inf << " is greater than " << max << '\n';}

	{double max = std::numeric_limits<int>::max();
	double inf = std::numeric_limits<int>::infinity();

	//if (inf > max)
		std::cout << inf << " is greater than " << max << "\n (INT)"; }
	
	std::cout << "\nHAS INFINITE (double)? " << std::numeric_limits<double>::has_infinity;
	std::cout << "\nHAS INFINITE (int)? " << std::numeric_limits<int>::has_infinity;
	//read: https://en.cppreference.com/w/cpp/types/numeric_limits/infinity

	std::cout << std::boolalpha
		<< "isinf(NaN) = " << std::isinf(NAN) << '\n'
		<< "isinf(Inf) = " << std::isinf(INFINITY) << '\n'
		<< "isinf(0.0) = " << std::isinf(0.0) << '\n'
		<< "isinf(exp(800)) = " << std::isinf(std::exp(800)) << '\n'
		<< "isinf(DBL_MIN/2.0) = " << std::isinf(DBL_MIN / 2.0) << '\n';

	std::cout << std::boolalpha
		<< "\n\nisnan(NaN) = " << std::isnan(NAN) << '\n'
		<< "isnan(Inf) = " << std::isnan(INFINITY) << '\n'
		<< "isnan(0.0) = " << std::isnan(0.0) << '\n'
		<< "isnan(DBL_MIN/2.0) = " << std::isnan(DBL_MIN / 2.0) << '\n'
		<< "isnan(Inf - Inf)   = " << std::isnan(INFINITY - INFINITY) << '\n';
	
	std::cout << std::boolalpha
		<< "\n\nisnan(NaN) = " << std::isnan(NAN) << '\n'
		<< "isnan(sqrt(-1.0)) = " << std::isnan(sqrt(-1.0)) << '\n';

	system("pause");
}