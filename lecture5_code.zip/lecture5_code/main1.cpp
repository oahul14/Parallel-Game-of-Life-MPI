#include <iostream>
#include <string>

#include "Animal.h"
#include "Duck.h"
#include "Horse.h"

using namespace std;

void someFunction(Animal * pAnimal)
{
	std::cout << pAnimal->GetNumberOfLegs();
}

int main()
{
	std::cout << "\nHow many legs do I have?";

	std::cout << "\nDuck:";
	Animal* animal = new Duck;
	someFunction(animal);
	std::cout << "\tNon-virtual function:" << animal->GetClass();

	std::cout << "\nHorse:";
	Animal* animal2 = new Horse;
	someFunction(animal2);
	std::cout << "\tNon-virtual function:" << animal2->GetClass() << endl;

	

	system("pause");


}