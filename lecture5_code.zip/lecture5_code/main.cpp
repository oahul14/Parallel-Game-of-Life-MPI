#include <iostream>
#include <string>

using namespace std;

class Animal
{
public:
	virtual int GetNumberOfLegs() = 0;
	std::string GetClass() { return "Animal"; }
};

class Duck : public Animal
{
public:
	int GetNumberOfLegs() { return 2; }
	std::string GetClass() { return "Duck"; }
};

class Horse : public Animal
{
public:
	int GetNumberOfLegs() { return 4; }
	std::string GetClass() { return "Horse"; }
};

void someFunction(Animal * pAnimal)
{
	std::cout << pAnimal->GetNumberOfLegs();
}

int main()
{
	std::cout << "\nHow many legs do I have?";

	std::cout << "\nDuck:";
	Animal* animal = new Duck;
	someFunction(animal);
	std::cout << "\tNon-virtual function:" << animal->GetClass();

	std::cout << "\nHorse:";
	Animal* animal2 = new Horse;
	someFunction(animal2);
	std::cout << "\tNon-virtual function:" << animal2->GetClass() << endl;

	system("pause");


}