#pragma once
#include <string>
#include "Animal.h"

class Duck : public Animal
{
public:
	int GetNumberOfLegs();
	std::string GetClass();
}; 
