#include <iostream>
#include <string>

#include "Animal.h"
#include "Duck.h"
#include "Horse.h"

using namespace std;

void someFunction(Animal * pAnimal)
{
	std::cout << pAnimal->GetNumberOfLegs();
}

int main()
{
	std::cout << "\nHow many legs do I have?";

	std::cout << "\nDuck:";
	Animal* animal = new Duck;
	someFunction(animal);
	std::cout << "\tNon-virtual function:" << animal->GetClass();

	std::cout << "\nHorse:";
	Animal* animal2 = new Horse;
	someFunction(animal2);
	std::cout << "\tNon-virtual function:" << animal2->GetClass() << endl;

	cerr << "\nINF: " << DBL_MAX + DBL_MAX << "\n";
	cerr << "\nINF: " << DBL_MAX + 1000 << "\n";
	cerr << "\nINF: " << DBL_MAX/(DBL_MAX+DBL_MAX) << "\n";
	//	cerr << "\nNAN: " << 1/0;

	std::cout << std::boolalpha
		<< "isinf(NaN) = " << std::isinf(NAN) << '\n'
		<< "isinf(Inf) = " << std::isinf(INFINITY) << '\n'
		<< "isinf(0.0) = " << std::isinf(0.0) << '\n'
		<< "isinf(exp(800)) = " << std::isinf(std::exp(800)) << '\n'
		<< "isinf(DBL_MIN/2.0) = " << std::isinf(DBL_MIN / 2.0) << '\n';

	system("pause");


}