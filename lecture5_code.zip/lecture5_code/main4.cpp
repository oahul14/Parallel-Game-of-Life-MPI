#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <list>
#include <algorithm>
using namespace std;

int main()
{
	std::vector<double> vector_of_ints;
	std::list<double> list_of_ints;
	std::set<double> set_of_ints;
	for (int i = 0; i < 10'000'000; i++)
	{
		vector_of_ints.push_back(rand()%100);
		list_of_ints.push_back(rand()%100);
		set_of_ints.insert(rand()%100);
	}
	
	for (int i = 0; i < 100'000; i++)
		vector_of_ints.erase(vector_of_ints.begin());
	for (int i = 0; i < 100'000; i++)
		list_of_ints.erase(list_of_ints.begin());
	for (int i = 0; i < 100'000; i++)
		set_of_ints.erase(set_of_ints.begin());
	
	for (int i = 0; i < 100'000; i++)
	{
		auto iter(find(vector_of_ints.begin(), vector_of_ints.end(), 100));
		if(iter != vector_of_ints.end())
			vector_of_ints.erase(iter);
	}
	for (int i = 0; i < 100'000; i++)
	{
		auto iter(find(list_of_ints.begin(), list_of_ints.end(), 100));
		if (iter != list_of_ints.end())
			list_of_ints.erase(iter);
	}	
	for (int i = 0; i < 100'000; i++)
	{
		auto iter(find(set_of_ints.begin(), set_of_ints.end(), 100));
		if (iter != set_of_ints.end())
			set_of_ints.erase(iter);
	}

	cerr << "\nEND";
	system("pause");
}